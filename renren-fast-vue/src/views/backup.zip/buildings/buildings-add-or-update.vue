<template>
  <el-dialog
    :title="!dataForm.buildingId ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
      <el-form-item label="楼栋号" prop="buildingId">
      <el-input v-model="dataForm.buildingId" placeholder="楼栋号"></el-input>
    </el-form-item>
    <el-form-item label="楼栋名" prop="buildingName">
      <el-input v-model="dataForm.buildingName" placeholder="楼栋名"></el-input>
    </el-form-item>
    <el-form-item label="组团名" prop="communityName">
      <el-input v-model="dataForm.communityName" placeholder="组团名"></el-input>
    </el-form-item>
    <el-form-item label="房间数量" prop="roomNumber">
      <el-input v-model="dataForm.roomNumber" placeholder="房间数量"></el-input>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        visible: false,
        dataForm: {
          buildingId: 0,
          buildingName: '',
          communityName: '',
          roomNumber: ''
        },
        dataRule: {
          buildingId: [
            { required: true, message: '楼栋号不能为空', trigger: 'blur' }
          ],
          buildingName: [
            { required: true, message: '楼栋名不能为空', trigger: 'blur' }
          ],
          communityName: [
            { required: true, message: '组团名不能为空', trigger: 'blur' }
          ],
          roomNumber: [
            { required: true, message: '房间数量不能为空', trigger: 'blur' }
          ]
        }
      }
    },
    methods: {

      init (id) {
        
        this.dataForm.buildingId = id || 0
        this.visible = true
        
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.buildingId) {
            this.$http({
              url: this.$http.adornUrl(`/buildings/buildings/info/${this.dataForm.buildingId}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.buildingId=data.buildings.buildingId
                this.dataForm.buildingName = data.buildings.buildingName
                this.dataForm.communityName = data.buildings.communityName
                this.dataForm.roomNumber = data.buildings.roomNumber
              }
            })
          }
        })
      },

      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`/buildings/buildings/${!this.dataForm.buildingId ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'buildingId': this.dataForm.buildingId || undefined,
                'buildingName': this.dataForm.buildingName,
                'communityName': this.dataForm.communityName,
                'roomNumber': this.dataForm.roomNumber
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
